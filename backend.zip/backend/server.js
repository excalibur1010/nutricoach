
require('dotenv').config();

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  process.exit(1); // Exit with a failure code
});

process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
  process.exit(1); // Exit with a failure code
});

const express = require('express');
const cors = require('cors');
const fs = require('fs');
const multer = require('multer');
const vision = require('@google-cloud/vision');
let client;

try {
  if (!process.env.GOOGLE_APPLICATION_CREDENTIALS) {
    console.warn('WARNING: GOOGLE_APPLICATION_CREDENTIALS environment variable is not set. Vision API might not work.');
    console.warn('Please set it to the path of your service account key file, or authenticate using `gcloud auth application-default login`.');
    client = { labelDetection: async () => [{ labelAnnotations: [] }] }; // Mock client
  } else {
    client = new vision.ImageAnnotatorClient();
  }
} catch (error) {
  console.error('Error initializing Google Cloud Vision client:', error);
  console.error('Please ensure your GOOGLE_APPLICATION_CREDENTIALS are correctly configured.');
  process.exit(1); // Exit if Vision client initialization fails
}

const app = express();
const port = 3001;
const gemini = require('./gemini');
const fetch = require('node-fetch');

app.use(express.json());
app.use(cors({ origin: 'http://localhost:3000' }));

const upload = multer({ storage: multer.memoryStorage() });

app.get('/', (req, res) => {
  res.send('Hello from the backend!');
});

// app.post('/api/vision/recognize', upload.single('image'), async (req, res) => {
//   if (!req.file) {
//     return res.status(400).json({ error: 'No image file provided.' });
//   }

//   try {
//     const [result] = await client.labelDetection({ image: { content: req.file.buffer } });
//     const labels = result.labelAnnotations;
//     const foodLabels = labels.filter(label => label.description.toLowerCase().includes('food') || label.description.toLowerCase().includes('meal') || label.description.toLowerCase().includes('dish'));

//     if (foodLabels.length > 0) {
//       // For hackathon, we'll just return the first food label as a placeholder.
//       // In a real app, you'd send these labels to Gemini for detailed nutrition.
//       const recognizedFood = foodLabels[0].description;
//       // Use Gemini to get nutritional info based on the recognized food
//       const prompt = `Provide estimated calories, protein, carbs, and fats for a typical serving of "${recognizedFood}" in JSON format. Example: { "name": "Chicken Breast", "calories": 165, "protein": 31, "carbs": 0, "fats": 3.6 }`;
//       const geminiResponse = await gemini.run(prompt);
//       const nutritionData = JSON.parse(geminiResponse);

//       res.json({ foods: [nutritionData] });
//     } else {
//       res.json({ foods: [] });
//     }
//   } catch (error) {
//     console.error('Error with Vision API or Gemini:', error);
//     res.status(500).json({ error: 'Failed to recognize food.' });
//   }
// });

app.post('/api/llm/chat', async (req, res) => {
  try {
    const { message } = req.body;
    const responseText = await gemini.run(message);

    // Attempt to strip markdown code block if present
    let cleanedResponseText = responseText;
    if (responseText.startsWith('```json') && responseText.endsWith('```')) {
      cleanedResponseText = responseText.substring(7, responseText.length - 3).trim();
    }

    try {
      const jsonResponse = JSON.parse(cleanedResponseText);
      res.json({ responseText: jsonResponse });
    } catch (jsonError) {
      // If it's not valid JSON, send the raw text response
      res.json({ responseText: responseText });
    }
  } catch (error) {
    console.error('Error calling Gemini API:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.post('/api/elevenlabs/speak', async (req, res) => {
  const { text } = req.body;
  const ELEVENLABS_API_KEY = process.env.ELEVENLABS_API_KEY;
  const ELEVENLABS_VOICE_ID = process.env.ELEVENLABS_VOICE_ID || '21m00Tcm4TlvDq8ikWAM'; // Default voice

  if (!ELEVENLABS_API_KEY) {
    return res.status(500).json({ error: 'ElevenLabs API key not configured.' });
  }

  try {
    const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${ELEVENLABS_VOICE_ID}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'xi-api-key': ELEVENLABS_API_KEY,
        },
        body: JSON.stringify({
          text: text,
          model_id: 'eleven_monolingual_v1',
          voice_settings: {
            stability: 0.5,
            similarity_boost: 0.5,
          },
        }),
      }
    );

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(`ElevenLabs API error: ${response.status} ${response.statusText} - ${JSON.stringify(errorData)}`);
    }

    const audioBuffer = await response.buffer();
    res.setHeader('Content-Type', 'audio/mpeg');
    res.send(audioBuffer);
  } catch (error) {
    console.error('Error calling ElevenLabs API:', error);
    res.status(500).json({ error: 'Internal Server Error for ElevenLabs TTS' });
  }
});

app.post('/api/meals/log', (req, res) => {
  const { meal } = req.body;
  const meals = JSON.parse(fs.readFileSync('meals.json', 'utf8'));
  meals.push({ ...meal, timestamp: new Date() });
  fs.writeFileSync('meals.json', JSON.stringify(meals, null, 2));
  res.json({ message: 'Meal logged successfully!' });
});

app.get('/api/meals', (req, res) => {
  const meals = JSON.parse(fs.readFileSync('meals.json', 'utf8'));
  res.json(meals);
});

app.get('/api/profile', (req, res) => {
  const profile = JSON.parse(fs.readFileSync('profile.json', 'utf8'));
  res.json(profile);
});

app.post('/api/profile', (req, res) => {
  const { profile } = req.body;
  fs.writeFileSync('profile.json', JSON.stringify(profile, null, 2));
  res.json({ message: 'Profile updated successfully!' });
});

app.get('/api/test', (req, res) => {
  res.json({ message: 'Hello from the test endpoint!' });
});

app.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}`);
});
